import * as RdfXmlParser from '../js/rdfjs/rdfxml-streaming-parser.js';
export {RdfXmlParser};